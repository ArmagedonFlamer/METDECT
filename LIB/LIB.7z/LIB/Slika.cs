﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIB
{
        public class Slika
    {
        public static List<Zvezda> Zvezde = new List<Zvezda>();
        public static List<Cluster> C = new List<Cluster>(); 
        public Slika(List<Zvezda> L)
        {
           Zvezde = L;
        }

        public static void AddZvezda(Zvezda Zvezda)
        {
            Zvezde.Add(Zvezda);
        }

        public unsafe static void Check(List<Zvezda> Z, Bitmap Img, BitmapData data)
        {
            byte* Ptr = (byte*) data.Scan0.ToPointer();
            Point TopLeft = Point.Empty, DownRight = Point.Empty;
            bool objekat;
            for (int i = 0; i < Z.Count; ++i)
            {
                TopLeft.X = Z[i].brunt.X - Z[i].length;
                TopLeft.Y = Z[i].brunt.Y - Z[i].length;
                DownRight.X = Z[i].brunt.X + Z[i].length;
                DownRight.Y = Z[i].brunt.Y + Z[i].length;

                if ((Z[i].brunt.X - Z[i].length < 0) || (Z[i].brunt.Y - Z[i].length < 0) ||
                    (Z[i].brunt.X + Z[i].length > Img.Width) || (Z[i].brunt.Y + Z[i].length > Img.Height))
                {
                    if (Z[i].brunt.X - Z[i].length < 0)
                        TopLeft.X = 0;
                    if (Z[i].brunt.Y - Z[i].length < 0)
                        TopLeft.Y = 0;
                    if (Z[i].brunt.X + Z[i].length > Img.Width)
                        DownRight.X = Img.Width;
                    if (Z[i].brunt.Y + Z[i].length > Img.Height)
                        DownRight.Y = Img.Height;
                }
                LIB LIB = new LIB();
                for (int j = 0; j < Zvezde[i].Coords.Count; ++j)
                    *(Ptr + Zvezde[i].Coords[j].Y*data.Stride + Zvezde[i].Coords[j].X) = 0;
                objekat = false;
                for (int j=TopLeft.Y; j<DownRight.Y;++j)
                    for (int k = TopLeft.X; k < DownRight.X; ++k)
                    {
                        if (*(Ptr + j*data.Stride + k) == 255)
                            objekat = true;
                    }
                if (objekat)
                    for (int j = 0; j < Zvezde[i].Coords.Count; ++j)
                        *(Ptr + Zvezde[i].Coords[j].Y*data.Stride + Zvezde[i].Coords[j].X) = 255;
                else
                {
                    Zvezde[i].Delete();
                    --i;
                }
            }
        }

        public unsafe static Bitmap DrawImage(Slika slika, Bitmap bmp)
        {
            Bitmap btm = new Bitmap(bmp.Width,bmp.Height);
            var LIB = new LIB();
            if (btm!=null)
                btm = LIB.ToGreyscale(btm);            
            BitmapData data = btm.LockBits(new Rectangle(0, 0, btm.Width, btm.Height), ImageLockMode.ReadWrite,
                btm.PixelFormat);
            byte* Ptr = (byte*) data.Scan0.ToPointer();
            for (int i=0;i<Zvezde.Count;++i)
                for (int j = 0; j < Zvezde[i].Coords.Count; ++j)
                {
                    *(Ptr + Zvezde[i].Coords[j].Y*data.Stride + Zvezde[i].Coords[j].X) = 255;
                }
            btm.UnlockBits(data);
           // Zvezde = new List<Zvezda>();
            return btm;
        }
    }

    public class Zvezda
    {
        public List<Point> Coords;
        public int length;
        public Point brunt;
        public Zvezda()
        {
            Coords = new List<Point>();
            length = 0;
        }

        public Zvezda(List<Point> L, int c, Point p)
        {
            Coords = new List<Point>(L);
            length = c;
            brunt = p;
        }

        public void Delete()
        {
            Slika.Zvezde.Remove(this);
        }
    }

    public class Cluster
    {
        public List<Zvezda> Z;
        public double k, n;
        public int o;

        public Cluster()
        {
            Z = new List<Zvezda>();
            k = 0;
            n = 0;
            o = 0;
        }

        public Cluster(List<Zvezda> L, double k1, double n1, int o1)
        {
            Z = new List<Zvezda>(L);
            k = k1;
            n = n1;
            o = o1;
        }
    }
}
