﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Imaging.Filters;
using LIB;

namespace meteors
{
    public unsafe partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private LIB.LIB lib = new LIB.LIB();

        private Bitmap first, second, third, fourth, of, os, ot, maskf, masks, maskt, maskc;

        private BitmapData dataF, dataS, dataT, dataM;

        private void button4_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog sfd = new FolderBrowserDialog();
            sfd.ShowDialog();
            Save = sfd.SelectedPath;
        }

        private int[][] visited;

        private string Open, Save;

        TimeSpan TS = new TimeSpan();
        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ofd = new FolderBrowserDialog();
            ofd.ShowDialog();
            Open = ofd.SelectedPath;
        }

        private unsafe void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            byte* PtrF, PtrS, PtrT;
            DateTime T = DateTime.Now;
            DirectoryInfo dir = new DirectoryInfo(Open);
            foreach (FileInfo flInfo in dir.GetFiles())
            {
                String Addr = flInfo.FullName;
                if (first == null)
                {
                    first = new Bitmap(Addr);
                    maskf = lib.CreateMask(first);
                    maskf.Save(@"C:\Users\Milenkom\Desktop\First.jpg");
                    int treshold = lib.Treshold(first);
                    first = lib.ToGreyscale(first);
                    lib.Nullify(ref first, treshold);
                    continue;
                }
                if (second == null)
                {
                    second = new Bitmap(Addr);
                    masks = lib.CreateMask(second);
                    int treshold = lib.Treshold(second);
                    second = lib.ToGreyscale(second);
                    lib.Nullify(ref second, treshold);
                    continue;
                }
                if (third == null)
                {
                    third = new Bitmap(Addr);
                    maskt = lib.CreateMask(third);
                    int treshold = lib.Treshold(third);
                    third = lib.ToGreyscale(third);
                    lib.Nullify(ref third, treshold);          

                    first = lib.OverLapBoth(first, second);
                    first = lib.OverLapBoth(first, maskf);
                    dataF = first.LockBits(new Rectangle(0, 0, first.Width, first.Height), ImageLockMode.ReadWrite,
                        first.PixelFormat);
                    dataM = maskf.LockBits(new Rectangle(0, 0, maskf.Width, maskf.Height), ImageLockMode.ReadWrite,
                        first.PixelFormat);
                    PtrF = (byte*)dataF.Scan0.ToPointer();
                    visited = new int[first.Width][];
                    for (int i = 0; i < first.Width; ++i)
                        visited[i] = new int[first.Height];
                    for (int i = 0; i < first.Height; ++i)
                        for (int j = 0; j < first.Width; ++j)
                            if ((*(PtrF + i * dataF.Stride + j) == 255) && (visited[j][i] == 0))
                                lib.FloodFillR(ref first, ref visited, j, i, 20, dataF);
                    visited = new int[first.Width][];
                    for (int i = 0; i < first.Width; ++i)
                        visited[i] = new int[first.Height];
                    lib.ApplyMask(ref first, maskf);
                    maskf.UnlockBits(dataM);
                    first.UnlockBits(dataF);

                    of = new Bitmap(first);
                    of = lib.ToGreyscale(of);
                    first = new Bitmap(second);
                    first = lib.ToGreyscale(first);

                    second = lib.OverLapBoth(second, third);
                    second = lib.OverLapBoth(second, masks);
                    dataS = second.LockBits(new Rectangle(0, 0, second.Width, second.Height),
                        ImageLockMode.ReadWrite,
                        second.PixelFormat);
                    dataM = masks.LockBits(new Rectangle(0, 0, masks.Width, masks.Height), ImageLockMode.ReadWrite,
                        second.PixelFormat);
                    PtrS = (byte*)dataS.Scan0.ToPointer();
                    visited = new int[second.Width][];
                    for (int i = 0; i < second.Width; ++i)
                        visited[i] = new int[second.Height];
                    for (int i = 0; i < second.Height; ++i)
                        for (int j = 0; j < second.Width; ++j)
                            if ((*(PtrS + i * dataS.Stride + j) == 255) && (visited[j][i] == 0))
                                lib.FloodFillR(ref second, ref visited, j, i, 20, dataS);
                    visited = new int[second.Width][];
                    for (int i = 0; i < second.Width; ++i)
                        visited[i] = new int[second.Height];
                    lib.ApplyMask(ref second, masks);
                    masks.UnlockBits(dataM);
                    second.UnlockBits(dataS);

                    os = new Bitmap(second);
                    os = lib.ToGreyscale(os);
                    second = new Bitmap(third);
                    second = lib.ToGreyscale(second);
                }
                if (fourth == null)
                {
                    fourth = new Bitmap(Addr);
                    maskc = lib.CreateMask(fourth);
                    int treshold = lib.Treshold(fourth);
                    fourth = lib.ToGreyscale(fourth);
                    lib.Nullify(ref fourth, treshold);
                    third = lib.OverLapBoth(third, fourth);
                    third = lib.OverLapBoth(third, maskt);
                    dataT = third.LockBits(new Rectangle(0, 0, third.Width, third.Height), ImageLockMode.ReadWrite,
                        third.PixelFormat);
                    dataM = maskt.LockBits(new Rectangle(0, 0, maskt.Width, maskt.Height), ImageLockMode.ReadWrite,
                       third.PixelFormat);
                    PtrT = (byte*)dataT.Scan0.ToPointer();
                    visited = new int[third.Width][];
                    for (int i = 0; i < third.Width; ++i)
                        visited[i] = new int[third.Height];
                    for (int i = 0; i < third.Height; ++i)
                        for (int j = 0; j < third.Width; ++j)
                            if ((*(PtrT + i * dataT.Stride + j) == 255) && (visited[j][i] == 0))
                                lib.FloodFillR(ref third, ref visited, j, i, 20, dataT);
                    visited = new int[third.Width][];
                    for (int i = 0; i < third.Width; ++i)
                        visited[i] = new int[third.Height];
                    lib.ApplyMask(ref third, maskt);
                    maskt.UnlockBits(dataM);
                    third.UnlockBits(dataT);

                    ot = new Bitmap(third);
                    ot = lib.ToGreyscale(ot);
                    third = new Bitmap(fourth);
                    third = lib.ToGreyscale(third);
                    fourth = null;

                    //Inicijalizovanje pozicija pocetnih zvezda na obradjenoj slici
                    dataF = of.LockBits(new Rectangle(0, 0, of.Width, of.Height), ImageLockMode.ReadWrite,
                          of.PixelFormat);
                    PtrF = (byte*)dataF.Scan0.ToPointer();
                    visited = new int[of.Width][];
                    for (int i = 0; i < of.Width; ++i)
                        visited[i] = new int[of.Height];
                    for (int i = 0; i < of.Width; ++i)
                        for (int j = 0; j < of.Height; ++j)
                        {
                            if ((*(PtrF + j * dataF.Stride + i) > 200) && (visited[i][j] == 0))
                            {
                                Zvezda Z = lib.FloodFillL(of, ref visited, i, j, dataF);
                                Z.length *= 2;
                                Slika.AddZvezda(Z);
                            }
                        }
                    of.UnlockBits(dataF);
                    //poredjenje sa druge dve slike
                    int n = Slika.Zvezde.Count;
                    dataF = of.LockBits(new Rectangle(0, 0, of.Width, of.Height), ImageLockMode.ReadWrite,
                        of.PixelFormat);
                    dataS = os.LockBits(new Rectangle(0, 0, os.Width, os.Height), ImageLockMode.ReadWrite,
                        os.PixelFormat);
                    dataT = ot.LockBits(new Rectangle(0, 0, ot.Width, ot.Height), ImageLockMode.ReadWrite,
                        ot.PixelFormat);
                    PtrF = (byte*)dataF.Scan0.ToPointer();
                    PtrS = (byte*)dataS.Scan0.ToPointer();
                    PtrT = (byte*)dataT.Scan0.ToPointer();
                    for (int i = 0; i < Slika.Zvezde.Count; ++i)
                    {
                        int tmp = i;
                        for (int j = 0; j < Slika.Zvezde[i].Coords.Count; ++j)
                        {
                            Point P = Slika.Zvezde[i].Coords[j];
                            if ((*(PtrS + P.Y * dataS.Stride + P.X) < 200) || (*(PtrT + P.Y * dataT.Stride + P.X) > 200))
                            {
                                Slika.Zvezde[i].Delete();
                                --i;
                                break;
                            }
                        }
                        if (Slika.Zvezde.Count == 0)
                            break;
                    }
                    if (Slika.Zvezde.Count != 0)
                    {
                        Bitmap bmp = Slika.DrawImage(new Slika(Slika.Zvezde), of);
                        bmp = lib.ToGreyscale(bmp);
                        BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite,
                            bmp.PixelFormat);
                        Slika.Check(Slika.Zvezde, bmp, data);
                        bmp.UnlockBits(data);
                        bmp.Save(Save + "\\" + flInfo.Name);
                    }

                    of.UnlockBits(dataF);
                    os.UnlockBits(dataS);
                    ot.UnlockBits(dataT);

                    //prebacujem sliku koja se analizira na sledecu i na njoj nalazim zvezde

                    // of = os;
                    /* of = lib.ToGreyscale(of);
                     dataF = of.LockBits(new Rectangle(0, 0, of.Width, of.Height), ImageLockMode.ReadWrite,
                         of.PixelFormat);
                     byte* Ptr = (byte*)dataF.Scan0.ToPointer();
                     visited = new int[of.Width][];
                     for (int i = 0; i < of.Width; ++i)
                         visited[i] = new int[of.Height];
                     for (int i = 0; i < of.Width; ++i)
                         for (int j = 0; j < of.Height; ++j)
                         {
                             if ((*(Ptr + j * dataF.Stride + i) > 200) && (visited[i][j] == 0))
                             {
                                 Zvezda Z = lib.FloodFillL(of, ref visited, i, j, dataF);
                                 Z.length *= 2;
                                 Slika.AddZvezda(Z);
                             }
                         }
                     of.UnlockBits(dataF);*/
                    of = os;
                    os = ot;
                    ot = null;
                    fourth = null;
                }
                GC.Collect();
            }
            DateTime T1 = DateTime.Now;
            TS = T1 - T;
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
          //  label1.Text = TS.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Change this path to the directory you want to read
            backgroundWorker1.RunWorkerAsync();
            //bmp = lib.ToGreyscale(bmp);
            // bmp.Save(@"C:\Users\milen\Desktop\GejScale.jpg");
        }
    }
}
